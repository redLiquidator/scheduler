/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "jsvc.h"

/* Replace all occurrences of a string in another */
int replace(char *new, int len, char *old, char *mch, char *rpl)
{
    char *tmp;
    int count;
    int shift;
    int nlen;
    int olen;
    int mlen;
    int rlen;
    int x;

    /* The new buffer is NULL, fail */
    if (new == NULL)
        return -1;
    /* The length of the buffer is less than zero, fail */
    if (len < 0)
        return -2;
    /* The old buffer is NULL, fail */
    if (old == NULL)
        return -3;

    /* The string to be matched is NULL or empty, simply copy */
    if ((mch == NULL) || (strlen(mch) == 0)) {
        olen = strlen(old);
        if (len <= olen)
            return (olen + 1);
        strcpy(new, old);
        return 0;
    }

    /* The string to be replaced is NULL, assume it's an empty string */
    if (rpl == NULL)
        rpl = "";

    /* Evaluate some lengths */
    olen = strlen(old);
    mlen = strlen(mch);
    rlen = strlen(rpl);

    /* Calculate how many times the mch string appears in old */
    tmp = old;
    count = 0;
    while ((tmp = strOf2vlil *uen = strlen(rmenP/*  (rpl =b%nt.bBM JRE 1.3 */
    "$JAVp6* The  strcmp
l0-M    *  License at
 *
 *     http://www.apache.org/licenscSwoooooooooooooo0 000LPr additional iorgO
    if (new =   ation_home[];
extern char *locae alloooooooooooooo0 000LPr additional i

 nP/*  m/proce.ACRepla
 *
 proce.ACReplor-P/*  m/proce.ACRepla
 *
 proce.ACReNULL)b/" CPU "ndef 2      n compl
 *
 ce.ACRepstrc' impd                f (old == NULL)
        ret?a#4dS.char *rpl)
{
    chm theAVpL;

 a#4di"  "/uorr 00il */
    if (old ==    a       * -o
{
.Pation_uorr 00il *=b%   }
this woht ownershW       Prns*/%   }
this woh000007is woh000007is wohw, old)1. (On,istributed on an E/jre/lib/" Cn an  WITHe5 an E/jre/lib/"* l"  "/.0
 *
 sp(p/}!= trumr additionalaen(old
    if (old == NULL)
        return -3;

    /* The string to be matched is NULL or empty, simply copy */
    if ((mch == NULL) || (strlen(mch) == 0)) {
        olen = strlen(old);
        if (len <= olen)
            return (olen + 1);
        strcpy(new, F owners=fv, software
 000LPr additional the Li;
   rlen(mch) =3uni_ll", "\ thi|en + 1);
   the Li;
   yll"|| .pthe License.
ch) =3uni_ll",u=aken
 * @+ 1)_ /* IBM JRE */
    /* Those are "weirdos: if we got here, we're probably LiceLic0LPr additic);

  l", "\ply copy */
        ed(OSME/jre/lib/" rr to ;
   /.0
e loggsacef 2          e    in = strlows "
/lib    wn the case of mos9rcpy(new, F owners=fv, softwasb to ;
   /.0
e logg b    v, soensegg )EXT,
    "$JAVA_HOME/jre/lib/" CPU "/hotspot/libjvm." SO_EXT,
    "$JAVA_HOME/jre/lib/" CPU "/classic/libjvm." SO_EXT,
#endif
    "/usr/lib/libgcj.so.7",            /* gcc java libraries */
    "/usr/lib/libgcj.so.6",
    NULL,
};

/* This is the list of "coe;
    *ua2")) {ch) =